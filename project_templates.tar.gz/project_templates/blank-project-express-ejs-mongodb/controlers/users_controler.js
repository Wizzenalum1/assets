module.exports.profile = function(req,res){
    res.render('user-profile');
}