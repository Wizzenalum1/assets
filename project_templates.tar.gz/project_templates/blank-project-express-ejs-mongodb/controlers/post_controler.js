module.exports.image = function(req,res){
    return res.end("<h1> this is my first post</h1>");
}