var head  = document.querySelector('footer');
head.style.color = "red";
head.style.fontSize = "3rem";